<form action="payment.php">

    <input type="submit" value="Оплатить">
</form>